#ifndef COMPARISONENGINE_H
#define COMPARISONENGINE_H

#include "Product.h"
#include <vector>

using namespace std;

class ComparisonEngine {
public:
    vector<Offer> sortOffersByPrice(const Product& product) const;
    double calculateSavings(const Product& product) const;
};

#endif
