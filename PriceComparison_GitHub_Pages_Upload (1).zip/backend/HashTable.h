#ifndef HASHTABLE_H
#define HASHTABLE_H

#include <iostream>
#include <list>
#include <vector>
#include <functional>

using namespace std;

// Hash table using separate chaining.
template <class K, class V>
class HashTable {
private:
    vector<list<pair<K, V>>> table;
    int capacity;
    int totalItems;

    int hashFunction(const K& key) const {
        return hash<K>{}(key) % capacity;
    }

public:
    HashTable(int size = 101) {
        capacity = (size > 0) ? size : 101;
        totalItems = 0;
        table.resize(capacity);
    }

    void insert(const K& key, const V& value) {
        int index = hashFunction(key);

        for (auto& item : table[index]) {
            if (item.first == key) {
                item.second = value;
                return;
            }
        }

        table[index].push_back({key, value});
        totalItems++;
    }

    bool search(const K& key, V& result) const {
        int index = hashFunction(key);

        for (const auto& item : table[index]) {
            if (item.first == key) {
                result = item.second;
                return true;
            }
        }

        return false;
    }

    bool contains(const K& key) const {
        V value;
        return search(key, value);
    }

    int size() const {
        return totalItems;
    }
};

#endif
