#include "BST.h"

using namespace std;

BST::BST() {
    root = nullptr;
}

BST::Node* BST::insertNode(Node* node, double price) {
    if (node == nullptr) {
        return new Node(price);
    }

    if (price < node->price) {
        node->left = insertNode(node->left, price);
    } else {
        node->right = insertNode(node->right, price);
    }

    return node;
}

void BST::insert(double price) {
    root = insertNode(root, price);
}

void BST::inorderTraversal(Node* node) const {
    if (node == nullptr) {
        return;
    }

    inorderTraversal(node->left);
    cout << node->price << " ";
    inorderTraversal(node->right);
}

void BST::displaySortedPrices() const {
    inorderTraversal(root);
    cout << endl;
}
