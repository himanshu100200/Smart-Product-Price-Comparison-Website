#ifndef TRIE_H
#define TRIE_H

#include <iostream>
#include <string>
#include <vector>
#include <map>

using namespace std;

class Trie {
private:
    struct Node {
        bool endOfWord;
        map<char, Node*> children;

        Node() {
            endOfWord = false;
        }
    };

    Node* root;

    void collectWords(Node* node, string current,
                      vector<string>& results) const;

public:
    Trie();
    ~Trie();

    void insert(string word);
    bool search(string word) const;
    vector<string> autocomplete(string prefix) const;
};

#endif
