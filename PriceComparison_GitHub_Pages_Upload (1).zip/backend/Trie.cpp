#include "Trie.h"
#include <cctype>

using namespace std;

Trie::Trie() {
    root = new Node();
}

Trie::~Trie() {
    // Nodes are retained until program exit in this simple project trie.
}

void Trie::insert(string word) {
    Node* current = root;

    for (char ch : word) {
        ch = static_cast<char>(tolower(static_cast<unsigned char>(ch)));

        if (current->children.find(ch) == current->children.end()) {
            current->children[ch] = new Node();
        }

        current = current->children[ch];
    }

    current->endOfWord = true;
}

bool Trie::search(string word) const {
    Node* current = root;

    for (char ch : word) {
        ch = static_cast<char>(tolower(static_cast<unsigned char>(ch)));

        if (current->children.find(ch) == current->children.end()) {
            return false;
        }

        current = current->children[ch];
    }

    return current->endOfWord;
}

void Trie::collectWords(Node* node, string current,
                        vector<string>& results) const {
    if (node->endOfWord) {
        results.push_back(current);
    }

    for (auto item : node->children) {
        collectWords(item.second, current + item.first, results);
    }
}

vector<string> Trie::autocomplete(string prefix) const {
    Node* current = root;

    for (char ch : prefix) {
        ch = static_cast<char>(tolower(static_cast<unsigned char>(ch)));

        if (current->children.find(ch) == current->children.end()) {
            return {};
        }

        current = current->children[ch];
    }

    vector<string> results;
    collectWords(current, prefix, results);
    return results;
}
