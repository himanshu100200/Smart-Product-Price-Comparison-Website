#include "Graph.h"

using namespace std;

void Graph::addProduct(int productId) {
    adjacencyList[productId];
}

void Graph::addConnection(int firstProduct, int secondProduct) {
    adjacencyList[firstProduct].push_back(secondProduct);
    adjacencyList[secondProduct].push_back(firstProduct);
}

void Graph::displaySimilarProducts(int productId) const {
    auto it = adjacencyList.find(productId);

    if (it == adjacencyList.end() || it->second.empty()) {
        cout << "No similar products found.\n";
        return;
    }

    cout << "Similar product IDs: ";

    for (int id : it->second) {
        cout << id << " ";
    }

    cout << endl;
}
