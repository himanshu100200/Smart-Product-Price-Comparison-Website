#ifndef GRAPH_H
#define GRAPH_H

#include <iostream>
#include <map>
#include <vector>

using namespace std;

class Graph {
private:
    map<int, vector<int>> adjacencyList;

public:
    void addProduct(int productId);
    void addConnection(int firstProduct, int secondProduct);
    void displaySimilarProducts(int productId) const;
};

#endif
