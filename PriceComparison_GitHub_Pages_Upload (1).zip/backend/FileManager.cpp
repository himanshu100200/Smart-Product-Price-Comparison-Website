#include "FileManager.h"
#include <fstream>

using namespace std;

bool FileManager::saveProducts(const string& fileName,
                               const vector<Product>& products) const {
    ofstream file(fileName);

    if (!file.is_open()) {
        return false;
    }

    for (const Product& product : products) {
        file << product.getId() << "|"
             << product.getName() << "|"
             << product.getBrand() << "|"
             << product.getCategory() << "\n";

        for (const Offer& offer : product.getOffers()) {
            file << offer.store << "|"
                 << offer.price << "|"
                 << offer.productUrl << "|"
                 << offer.demo << "\n";
        }

        file << "END\n";
    }

    file.close();
    return true;
}
