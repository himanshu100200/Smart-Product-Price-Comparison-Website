#ifndef RECOMMENDATION_H
#define RECOMMENDATION_H

#include "Graph.h"

using namespace std;

class Recommendation {
private:
    Graph productGraph;

public:
    void addSimilarity(int firstId, int secondId);
    void recommend(int productId) const;
};

#endif
