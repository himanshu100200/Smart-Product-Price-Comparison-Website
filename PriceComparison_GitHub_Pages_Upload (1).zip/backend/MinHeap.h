#ifndef MINHEAP_H
#define MINHEAP_H

#include <iostream>
#include <vector>
#include <stdexcept>
#include <utility>

using namespace std;

// Generic minimum heap.
template <class T>
class MinHeap {
private:
    vector<T> heap;

    void heapifyUp(int index) {
        while (index > 0) {
            int parent = (index - 1) / 2;

            if (heap[parent] <= heap[index]) {
                break;
            }

            swap(heap[parent], heap[index]);
            index = parent;
        }
    }

    void heapifyDown(int index) {
        int size = heap.size();

        while (true) {
            int left = 2 * index + 1;
            int right = 2 * index + 2;
            int smallest = index;

            if (left < size && heap[left] < heap[smallest]) {
                smallest = left;
            }

            if (right < size && heap[right] < heap[smallest]) {
                smallest = right;
            }

            if (smallest == index) {
                break;
            }

            swap(heap[index], heap[smallest]);
            index = smallest;
        }
    }

public:
    void insert(const T& value) {
        heap.push_back(value);
        heapifyUp(heap.size() - 1);
    }

    T getMinimum() const {
        if (heap.empty()) {
            throw runtime_error("Heap is empty");
        }

        return heap[0];
    }

    T removeMinimum() {
        if (heap.empty()) {
            throw runtime_error("Heap is empty");
        }

        T minimum = heap[0];
        heap[0] = heap.back();
        heap.pop_back();

        if (!heap.empty()) {
            heapifyDown(0);
        }

        return minimum;
    }

    bool isEmpty() const {
        return heap.empty();
    }

    int size() const {
        return heap.size();
    }
};

#endif
