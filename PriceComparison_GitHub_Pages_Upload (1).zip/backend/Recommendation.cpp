#include "Recommendation.h"

using namespace std;

void Recommendation::addSimilarity(int firstId, int secondId) {
    productGraph.addConnection(firstId, secondId);
}

void Recommendation::recommend(int productId) const {
    productGraph.displaySimilarProducts(productId);
}
