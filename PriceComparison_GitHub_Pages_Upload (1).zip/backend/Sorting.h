#ifndef SORTING_H
#define SORTING_H

#include <iostream>
#include <vector>

using namespace std;

class Sorting {
public:
    static void mergeSort(vector<double>& values);
    static void quickSort(vector<double>& values, int low, int high);

private:
    static void merge(vector<double>& values, int left,
                      int middle, int right);
    static int partition(vector<double>& values, int low, int high);
};

#endif
