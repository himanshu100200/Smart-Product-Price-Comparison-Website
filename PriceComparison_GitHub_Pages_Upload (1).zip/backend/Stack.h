#ifndef STACK_H
#define STACK_H

#include <iostream>
#include <vector>
#include <stdexcept>

using namespace std;

template <class T>
class Stack {
private:
    vector<T> items;

public:
    void push(const T& value) {
        items.push_back(value);
    }

    void pop() {
        if (items.empty()) {
            cout << "Stack is empty.\n";
            return;
        }

        items.pop_back();
    }

    T top() const {
        if (items.empty()) {
            throw runtime_error("Stack is empty");
        }

        return items.back();
    }

    bool isEmpty() const {
        return items.empty();
    }

    int size() const {
        return items.size();
    }
};

#endif
