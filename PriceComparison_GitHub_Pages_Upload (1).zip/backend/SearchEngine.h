#ifndef SEARCHENGINE_H
#define SEARCHENGINE_H

#include "Product.h"
#include "Trie.h"
#include <vector>

using namespace std;

class SearchEngine {
private:
    Trie productNames;

public:
    void buildIndex(const vector<Product>& products);
    vector<string> searchSuggestions(string prefix) const;
};

#endif
