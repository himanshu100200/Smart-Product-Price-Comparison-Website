#include "ComparisonEngine.h"
#include <algorithm>

using namespace std;

vector<Offer> ComparisonEngine::sortOffersByPrice(
    const Product& product) const {

    vector<Offer> offers = product.getOffers();

    sort(offers.begin(), offers.end(),
         [](const Offer& first, const Offer& second) {
             return first.price < second.price;
         });

    return offers;
}

double ComparisonEngine::calculateSavings(const Product& product) const {
    vector<Offer> offers = product.getOffers();

    if (offers.size() < 2) {
        return 0;
    }

    double lowest = offers[0].price;
    double highest = offers[0].price;

    for (const Offer& offer : offers) {
        lowest = min(lowest, offer.price);
        highest = max(highest, offer.price);
    }

    return highest - lowest;
}
