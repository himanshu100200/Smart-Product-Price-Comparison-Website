#ifndef FILEMANAGER_H
#define FILEMANAGER_H

#include "Product.h"
#include <string>
#include <vector>

using namespace std;

class FileManager {
public:
    bool saveProducts(const string& fileName,
                      const vector<Product>& products) const;
};

#endif
