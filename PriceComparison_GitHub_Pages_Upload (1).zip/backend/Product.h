#ifndef PRODUCT_H
#define PRODUCT_H

#include <iostream>
#include <string>
#include <vector>

using namespace std;

struct Offer {
    string store;
    double price;
    string productUrl;
    bool demo;

    Offer(string storeName, double offerPrice,
          string url, bool isDemo = true);
};

class Product {
private:
    int id;
    string name;
    string brand;
    string category;
    vector<Offer> offers;

public:
    Product();
    Product(int productId, string productName,
            string productBrand, string productCategory);

    int getId() const;
    string getName() const;
    string getBrand() const;
    string getCategory() const;

    void addOffer(const Offer& offer);
    vector<Offer> getOffers() const;

    double lowestPrice() const;
    bool hasOffers() const;
    void displayProduct() const;
};

#endif
