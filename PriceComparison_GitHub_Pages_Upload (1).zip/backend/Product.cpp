#include "Product.h"
#include <algorithm>
#include <limits>

using namespace std;

Offer::Offer(string storeName, double offerPrice,
             string url, bool isDemo)
    : store(storeName), price(offerPrice),
      productUrl(url), demo(isDemo) {
}

Product::Product() {
    id = 0;
}

Product::Product(int productId, string productName,
                 string productBrand, string productCategory)
    : id(productId), name(productName),
      brand(productBrand), category(productCategory) {
}

int Product::getId() const {
    return id;
}

string Product::getName() const {
    return name;
}

string Product::getBrand() const {
    return brand;
}

string Product::getCategory() const {
    return category;
}

void Product::addOffer(const Offer& offer) {
    if (offer.price > 0) {
        offers.push_back(offer);
    }
}

vector<Offer> Product::getOffers() const {
    return offers;
}

double Product::lowestPrice() const {
    if (offers.empty()) {
        return numeric_limits<double>::max();
    }

    double lowest = offers[0].price;

    for (const Offer& offer : offers) {
        if (offer.price < lowest) {
            lowest = offer.price;
        }
    }

    return lowest;
}

bool Product::hasOffers() const {
    return !offers.empty();
}

void Product::displayProduct() const {
    cout << "\nProduct ID : " << id << endl;
    cout << "Name       : " << name << endl;
    cout << "Brand      : " << brand << endl;
    cout << "Category   : " << category << endl;

    if (offers.empty()) {
        cout << "No offers available.\n";
        return;
    }

    cout << "\nAvailable Offers:\n";

    for (const Offer& offer : offers) {
        cout << offer.store << " : Rs. "
             << offer.price;

        if (offer.demo) {
            cout << " [DEMO]";
        }

        cout << endl;
    }

    cout << "Lowest Price: Rs. " << lowestPrice() << endl;
}
