#include "Product.h"
#include "HashTable.h"
#include "MinHeap.h"
#include "BST.h"
#include "Graph.h"
#include "Stack.h"
#include "Sorting.h"
#include "SearchEngine.h"
#include "ComparisonEngine.h"
#include "Recommendation.h"
#include "FileManager.h"

#include <iostream>
#include <vector>
#include <iomanip>

using namespace std;

int main() {
    vector<Product> products;

    Product sony(101, "Sony WH-CH520 Headphones",
                 "Sony", "Electronics");
    sony.addOffer(Offer("Amazon", 2499, "https://www.amazon.in"));
    sony.addOffer(Offer("Flipkart", 2299, "https://www.flipkart.com"));
    sony.addOffer(Offer("Croma", 2599, "https://www.croma.com"));

    Product iphone(102, "Apple iPhone 17",
                   "Apple", "Mobiles");
    iphone.addOffer(Offer("Amazon", 79999, "https://www.amazon.in"));
    iphone.addOffer(Offer("Flipkart", 78999, "https://www.flipkart.com"));

    Product nike(103, "Nike Air Max Shoes",
                 "Nike", "Fashion");
    nike.addOffer(Offer("Myntra", 5499, "https://www.myntra.com"));
    nike.addOffer(Offer("Amazon", 5999, "https://www.amazon.in"));

    products.push_back(sony);
    products.push_back(iphone);
    products.push_back(nike);

    HashTable<int, int> productTable;
    SearchEngine searchEngine;
    ComparisonEngine comparisonEngine;
    Recommendation recommendation;
    Stack<int> recentlyViewed;
    BST priceTree;

    for (int i = 0; i < products.size(); i++) {
        productTable.insert(products[i].getId(), i);
        priceTree.insert(products[i].lowestPrice());
    }

    searchEngine.buildIndex(products);

    recommendation.addSimilarity(101, 102);
    recommendation.addSimilarity(101, 103);

    int choice;

    do {
        cout << "\n========== PRICE COMPARISON SYSTEM ==========\n";
        cout << "1. Display all products\n";
        cout << "2. Search product suggestions\n";
        cout << "3. Compare product prices\n";
        cout << "4. Recommend similar products\n";
        cout << "5. Recently viewed products\n";
        cout << "6. Save products to file\n";
        cout << "7. Display sorted prices using BST\n";
        cout << "0. Exit\n";
        cout << "Enter choice: ";
        cin >> choice;

        switch (choice) {
        case 1:
            for (const Product& product : products) {
                product.displayProduct();
            }
            break;

        case 2: {
            string prefix;
            cout << "Enter product prefix: ";
            cin >> prefix;

            vector<string> results =
                searchEngine.searchSuggestions(prefix);

            if (results.empty()) {
                cout << "No suggestions found.\n";
            }

            for (const string& name : results) {
                cout << name << endl;
            }
            break;
        }

        case 3: {
            int id;
            cout << "Enter product ID: ";
            cin >> id;

            int index;
            if (!productTable.search(id, index)) {
                cout << "Product not found.\n";
                break;
            }

            Product selected = products[index];
            vector<Offer> offers =
                comparisonEngine.sortOffersByPrice(selected);

            cout << "\nOffers sorted by price:\n";

            for (const Offer& offer : offers) {
                cout << offer.store << " : Rs. "
                     << offer.price << " [DEMO]\n";
            }

            cout << "Potential savings: Rs. "
                 << comparisonEngine.calculateSavings(selected) << endl;

            recentlyViewed.push(id);
            break;
        }

        case 4: {
            int id;
            cout << "Enter product ID: ";
            cin >> id;
            recommendation.recommend(id);
            break;
        }

        case 5:
            if (recentlyViewed.isEmpty()) {
                cout << "No recently viewed products.\n";
            } else {
                cout << "Most recently viewed product ID: "
                     << recentlyViewed.top() << endl;
            }
            break;

        case 6: {
            FileManager manager;
            if (manager.saveProducts("products.txt", products)) {
                cout << "Products saved successfully.\n";
            } else {
                cout << "Unable to save products.\n";
            }
            break;
        }

        case 7:
            cout << "BST price ordering is available in the BST module.\n";
            break;

        case 0:
            cout << "Exiting Price Comparison System.\n";
            break;

        default:
            cout << "Invalid choice. Try again.\n";
        }

    } while (choice != 0);

    return 0;
}
