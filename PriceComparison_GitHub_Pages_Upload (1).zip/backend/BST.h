#ifndef BST_H
#define BST_H

#include <iostream>

using namespace std;

// Binary Search Tree for organising prices.
class BST {
private:
    struct Node {
        double price;
        Node* left;
        Node* right;

        Node(double value) {
            price = value;
            left = nullptr;
            right = nullptr;
        }
    };

    Node* root;

    Node* insertNode(Node* node, double price);
    void inorderTraversal(Node* node) const;

public:
    BST();
    void insert(double price);
    void displaySortedPrices() const;
};

#endif
