#include "Sorting.h"
#include <algorithm>
#include <utility>

using namespace std;

void Sorting::merge(vector<double>& values, int left,
                    int middle, int right) {
    vector<double> first(values.begin() + left, values.begin() + middle + 1);
    vector<double> second(values.begin() + middle + 1, values.begin() + right + 1);

    int i = 0;
    int j = 0;
    int k = left;

    while (i < first.size() && j < second.size()) {
        if (first[i] <= second[j]) {
            values[k++] = first[i++];
        } else {
            values[k++] = second[j++];
        }
    }

    while (i < first.size()) {
        values[k++] = first[i++];
    }

    while (j < second.size()) {
        values[k++] = second[j++];
    }
}

void Sorting::mergeSort(vector<double>& values) {
    int size = values.size();

    for (int width = 1; width < size; width *= 2) {
        for (int left = 0; left < size - width; left += 2 * width) {
            int middle = left + width - 1;
            int right = min(left + 2 * width - 1, size - 1);
            merge(values, left, middle, right);
        }
    }
}

int Sorting::partition(vector<double>& values, int low, int high) {
    double pivot = values[high];
    int smaller = low - 1;

    for (int j = low; j < high; j++) {
        if (values[j] <= pivot) {
            smaller++;
            swap(values[smaller], values[j]);
        }
    }

    swap(values[smaller + 1], values[high]);
    return smaller + 1;
}

void Sorting::quickSort(vector<double>& values, int low, int high) {
    if (low < high) {
        int pivot = partition(values, low, high);
        quickSort(values, low, pivot - 1);
        quickSort(values, pivot + 1, high);
    }
}
