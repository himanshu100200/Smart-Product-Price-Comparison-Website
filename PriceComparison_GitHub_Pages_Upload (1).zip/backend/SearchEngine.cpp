#include "SearchEngine.h"

using namespace std;

void SearchEngine::buildIndex(const vector<Product>& products) {
    for (const Product& product : products) {
        productNames.insert(product.getName());
    }
}

vector<string> SearchEngine::searchSuggestions(string prefix) const {
    return productNames.autocomplete(prefix);
}
